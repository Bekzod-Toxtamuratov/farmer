import {
  Controller,
  Get,
  Post,
  Body,
  Patch,
  Param,
  Delete,
  Inject,
} from '@nestjs/common';
import { BookService } from './book.service';
import { CreateBookDto } from './dto/create-book.dto';
import { UpdateBookDto } from './dto/update-book.dto';
import { ClientProxy } from '@nestjs/microservices';

@Controller('book')
export class BookController {
  constructor(
    private readonly bookService: BookService,
    @Inject('PRODUCT SERVICE') private readonly clientService: ClientProxy,
  ) {}

  @Post()
  async create(@Body() createBookDto: CreateBookDto) {
    const book = await this.bookService.create(createBookDto);

    console.log('book', book);
    this.clientService.emit('book_created', book);
    return book;
  }
  @Get()
  findAll() {
    return this.bookService.findAll();
  }

  @Get(':id')
  findOne(@Param('id') id: string) {
    return this.bookService.findOne(+id);
  }

  // @Patch(':id')
  // update(@Param('id') id: string, @Body() updateBookDto: UpdateBookDto) {
  //   return this.bookService.update(+id, updateBookDto);
  // }
  @Patch(':id')
  async update(@Param('id') id: string, @Body() updateBookDto: UpdateBookDto) {
    await this.bookService.update(+id, updateBookDto);
    const book = await this.bookService.findOne(+id);
    this.clientService.emit('book_updated', book);
    return book;
  }
  /* @Patch(':id')
  async update(
    @Param('id') id: string,
    @Body() updateProductDto: UpdateProductDto,
  ) {
    await this.productService.update(+id, updateProductDto);
    const product = await this.productService.findOne(+id);
    this.clientService.emit('product_updated', product);
    return product;
  } */

  @Delete(':id')
  async remove(@Param('id') id: string) {
    await this.bookService.remove(+id);
    this.clientService.emit('book_deleted', id);
    return id;
  }
}
