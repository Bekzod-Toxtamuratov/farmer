import { Injectable } from '@nestjs/common';
import { CreateBookDto } from './dto/create-book.dto';
import { UpdateBookDto } from './dto/update-book.dto';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { Book } from './entities/book.entity';

@Injectable()
export class BookService {
  constructor(@InjectRepository(Book) private bookRepo: Repository<Book>) {}

  create(createBookDto: CreateBookDto) {
    console.log('createBookDto', createBookDto);
    const { name, page, price } = createBookDto;
    return this.bookRepo.save({ name, page, price });
  }

  findAll() {
    return this.bookRepo.find();
  }

  findOne(id: number) {
    return this.bookRepo.findOneBy({ id });
  }

  update(id: number, updateBookDto: UpdateBookDto) {
    return this.bookRepo.update({ id }, updateBookDto);
  }

  remove(id: number) {
    return this.bookRepo.delete({ id });
  }
}
