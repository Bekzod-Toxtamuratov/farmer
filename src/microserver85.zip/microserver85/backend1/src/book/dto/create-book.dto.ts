export class CreateBookDto {

  name: string;
  page: string;
  price: number;
  
}
