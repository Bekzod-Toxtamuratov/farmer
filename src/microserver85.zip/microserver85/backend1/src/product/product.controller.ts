import {
  Controller,
  Get,
  Post,
  Body,
  Patch,
  Param,
  Delete,
  Inject,
  NotFoundException,
} from '@nestjs/common';
import { ProductService } from './product.service';
import { CreateProductDto } from './dto/create-product.dto';
import { UpdateProductDto } from './dto/update-product.dto';
import { ClientProxy } from '@nestjs/microservices';

@Controller('product')
export class ProductController {
  constructor(
    private readonly productService: ProductService,
    @Inject('PRODUCT SERVICE') private readonly clientService: ClientProxy,
  ) {}

  @Post(':id/like')
  async likeBoss(@Param('id') id: string) {
    let product = await this.productService.findOne(+id);
    if (!product) {
      throw new NotFoundException('Bunday product  topilmadi');
    }
    product.likes += 1;
    await this.productService.update(+id, product);
    return product;
  }

  @Post()
  async create(@Body() createProductDto: CreateProductDto) {
    const product = await this.productService.create(createProductDto);
    this.clientService.emit('products_created', product);
    return product;
  }

  @Get()
  findAll() {
    // this.clientService
    //   .emit('hello', 'Hello from another server!')
    //   .subscribe((data) => {
    //     console.log('data', data);
    //   });

    // this.clientService
    //   .send('salom', 'salom from another server!')
    //   .subscribe((data) => {
    //     console.log('data', data);
    //   });
    return this.productService.findAll();
  }

  @Get(':id')
  findOne(@Param('id') id: string) {
    return this.productService.findOne(+id);
  }

  //  @Patch(':id')
  //  async update(@Param('id') id: string, @Body() updateProductDto: UpdateProductDto) {

  //   const product =await this.productService.update(+id, updateProductDto);
  //   this.clientService.emit('products_created12',product);
  // }
  @Patch(':id')
  async update(
    @Param('id') id: string,
    @Body() updateProductDto: UpdateProductDto,
  ) {
    await this.productService.update(+id, updateProductDto);
    const product = await this.productService.findOne(+id);
    this.clientService.emit('product_updated', product);
    return product;
  }

  @Delete(':id')
  async remove(@Param('id') id: string) {
    await this.productService.remove(+id);
    this.clientService.emit('product_deleted', id);
    return id;
  }
}
