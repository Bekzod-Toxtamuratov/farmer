export class CreateProductDto {
  title: string;
  image: string;
}
