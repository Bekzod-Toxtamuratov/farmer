import {
  Controller,
  Get,
  Post,
  Body,
  Patch,
  Param,
  Delete,
} from '@nestjs/common';
import { ProductService } from './product.service';
import { CreateProductDto } from './dto/create-product.dto';
import { UpdateProductDto } from './dto/update-product.dto';
import { EventPattern, MessagePattern } from '@nestjs/microservices';

@Controller('product')
export class ProductMicroServiceController {
  constructor(private readonly productService: ProductService) {}

  @EventPattern('hello')
  async hello(data: string) {
    console.log('data', data);
    return 'hello keldi';
  }
  @MessagePattern('hello')
  async salom(data: string) {
    console.log('data', data);
    return 'salom keldi';
  }

  // ***********************

  @EventPattern('products_created')
  create(@Body() createProductDto: CreateProductDto) {
    return this.productService.create(createProductDto);
  }

  // @Get()
  // findAll() {
  //   return this.productService.findAll();
  // }

  // @Get(':id')
  // findOne(@Param('id') id: string) {
  //   return this.productService.findOne(+id);
  // }

  @EventPattern('product_updated')
  async update(@Body() updateProductDto: UpdateProductDto) {
    const { id, ...updateProducto } = updateProductDto;
    return this.productService.update(+id, updateProducto);
  }

  @EventPattern('product_deleted')
  @Delete(':id')
  remove(id: string) {
    return this.productService.remove(+id);
  }
}
