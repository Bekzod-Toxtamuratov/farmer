// import { Product } from './entities/product.entity';
import { Injectable } from '@nestjs/common';
import { CreateProductDto } from './dto/create-product.dto';
import { UpdateProductDto } from './dto/update-product.dto';
import { Product } from './schemas/product..schemas';
import { Model } from 'mongoose';
import { InjectModel } from '@nestjs/mongoose';

@Injectable()
export class ProductService {
  constructor(
    @InjectModel(Product.name) private ProductModel: Model<Product>,
  ) {}

  create(createProductDto: CreateProductDto) {
    return this.ProductModel.create(createProductDto);
  }

  findAll() {
    return this.ProductModel.find();
  }

  findOne(id: number) {
    return this.ProductModel.findOne({ id });
  }

  update(id: number, updateProductDto: UpdateProductDto) {
    return this.ProductModel.findOneAndUpdate({ id }, updateProductDto, {
      new: true,
    });
  }

  remove(id: number) {
    return this.ProductModel.findOneAndDelete({ id });
  }
}
