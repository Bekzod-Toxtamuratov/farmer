import {
  Controller,
  Get,
  Post,
  Body,
  Patch,
  Param,
  Delete,
} from '@nestjs/common';
import { EventPattern } from '@nestjs/microservices';
import { CreateBookDto } from './dto/create-book.dto';
import { BookService } from './book.service';
import { UpdateBookDto } from './dto/update-book.dto';

@Controller('book')
export class BookMicroServiceController {
  constructor(private readonly bookService: BookService) {}

  @EventPattern('hello')
  async hello(data: string) {
    console.log('data', data);
  }
  // book_created
  @EventPattern('book_created')
  create(@Body() createProductDto: CreateBookDto) {
    console.log('createProductDto', createProductDto);
    return this.bookService.create(createProductDto);
  }

  // @Get()
  // findAll() {
  //   return this.productService.findAll();
  // }

  // @Get(':id')
  // findOne(@Param('id') id: string) {
  //   return this.productService.findOne(+id);
  // }
  // book_updated

  @EventPattern('book_updated')
  async update(@Body() updateBookDto: UpdateBookDto) {
    const { id, ...updateBookDto12 } = updateBookDto;
    return this.bookService.update(+id, updateBookDto12);
  }

  @EventPattern('book_deleted')
  @Delete(':id')
  remove(id: string) {
    return this.bookService.remove(+id);
  }
}
