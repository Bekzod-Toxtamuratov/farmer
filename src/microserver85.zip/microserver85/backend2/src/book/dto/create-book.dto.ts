export class CreateBookDto {
  id: number;
  name: string;
  page: string;
  price: number;
}
