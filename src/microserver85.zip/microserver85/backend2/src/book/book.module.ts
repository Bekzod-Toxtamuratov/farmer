import { Module } from '@nestjs/common';
import { MongooseModule } from '@nestjs/mongoose';
import { HttpModule } from '@nestjs/axios';
import { BookController } from './book.controller';
import { BookMicroServiceController } from './book-microService.controller';
import { BookSchema, Book } from './schemas/book.schemas';
import { BookService } from './book.service';
@Module({
  imports: [
    MongooseModule.forFeature([{ name: Book.name, schema: BookSchema }]),
    HttpModule,
  ],
  controllers: [BookController, BookMicroServiceController],
  providers: [BookService],
})
export class BookModule {}
